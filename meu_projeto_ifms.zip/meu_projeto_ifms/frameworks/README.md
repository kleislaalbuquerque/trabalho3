## Como usar

git clone https://gitlab.com/ifms-aulas/frameworks.git

cd frameworks

Abra o terminal git branch para escolher qual branch você quer usar

```bash
git branch
```

Depois de escolher a branch que você quer usar, faça o checkout para ela. Normalmente vou nomear como Aula01, Aula02, etc.

```bash 
git checkout nome-da-branch
```

Depois de fazer o checkout para a branch que você quer usar, faça o pull para atualizar a branch

```bash
git pull
```

!!!!!ATENÇÃO!!!!! Crie o arquivo .env baseado no .env.example. Apenas control c + control v e renomeie para .env 
Ajuste o arquivo .env com as configurações do seu banco de dados

Instale as dependências do projeto

```bash
composer update
```

Gere a chave do projeto

```bash
php artisan key:generate
```

Rode as migrations

```bash
php artisan migrate
```

Rodar as seeds

```bash
php artisan db:seed --class=AlunosTableSeeder
```

Rode o servidor

```bash
php artisan serve
```

[//]: # (glpat-Rj2x9B-o4AbaCQHrXbzq)
