<html>
<body>
<div>
    <h1>Lista de Alunos</h1>
    @error('erro')
        <div>{{ $message }}</div>
    @enderror

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Curso</th>
        </tr>
        </thead>
        <tbody>
        <tbody>
        @foreach ($alunos as $aluno)
            <tr>
                <td>{{ $aluno->id }}</td>
                <td>{{ $aluno->nome }}</td>
                <td>{{ $aluno->email }}</td>
                <td>{{ $aluno->curso->nome_curso }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>


