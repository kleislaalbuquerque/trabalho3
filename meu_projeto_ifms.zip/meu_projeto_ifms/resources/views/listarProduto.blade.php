<html>
<body>
<div>
    <h1>Lista de Produtos</h1>
    @error('erro')
        <div>{{ $message }}</div>
    @enderror

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Valor do produto</th>
            <th>Data de validade</th>
            <th>Marca associada</th>
        </tr>
        </thead>
        <tbody>
        <tbody>
        @foreach ($produtos as $produto)
            <tr>
                <td>{{ $produto->nome }}</td>
                <td>{{ $produto->valor_produto }}</td>
                <td>{{ $produto->data_validade }}</td>
                <td>{{ $produto->marca_associada }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>
