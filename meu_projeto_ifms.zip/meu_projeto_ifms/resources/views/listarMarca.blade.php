<html>
<body>
<div>
    <h1>Lista de Marcas</h1>
    @error('erro')
        <div>{{ $message }}</div>
    @enderror

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
        </tr>
        </thead>
        <tbody>
        <tbody>
        @foreach ($marcas as $marca)
            <tr>
                <td>{{ $marcas->id }}</td>
                <td>{{ $marcas->nome }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>
