<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Produto;
class ProdutoController extends Controller
{
    public function listar()
    {
        $produtos = Produtos::all();
        return view('listarProdutos')->with('produtos', $produtos);
    }

    public function listarID($id)
    {
        $produtos = Produtos::find($id);
        if ($produtos) {
            return view('visualizarProdutos')->with('produtos', $produtos);
        } else {
            return redirect('/produtos')->withErrors(['erro' => 'produto não encontrado!']);
        }
    }

    public function store(Request $request)
    {
        $produto = new Produtos;
        $produto->nome = $request->nome;
        $produto->valor_produto = $request->valor_produto;
        $produto->data_validade = $request->data_validade;
        $produto->marca_associada = $request->marca_associada;
        $produto->save();

        return redirect()->route('produtos.listar');
    }

    public function criar() {
        return view('novoProdutos');
    }

    public function update(Request $request) {
        $produto = Produtos::find($request->id);
        $produto->nome = $request->nome;
        $produto->valor_produto = $request->valor_produto;
        $produto->data_validade = $request->data_validade;
        $produto->marca_associada = $request->marca_associada;
        $produto->save();

        return redirect()->route('produtos.listar');
    }
}
