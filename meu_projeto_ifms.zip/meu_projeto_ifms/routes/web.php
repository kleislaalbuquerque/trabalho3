<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/marcas', [App\Http\Controllers\AlunoController::class, 'listar'])
    ->name('marcas.listar');
Route::get('/marcas/{id}', [App\Http\Controllers\AlunoController::class, 'listarID']);

Route::get('novoMarca', [App\Http\Controllers\AlunoController::class, 'criar']);

Route::post('salvarMarca', [App\Http\Controllers\AlunoController::class, 'store'])
    ->name('Marca.salvar');

Route::post('atualizarMarca', [App\Http\Controllers\AlunoController::class, 'update'])
    ->name('marcas.atualizar');


Route::get('/produtos', [App\Http\Controllers\AlunoController::class, 'listar'])
    ->name('produtos.listar');
Route::get('/produtos/{id}', [App\Http\Controllers\AlunoController::class, 'listarID']);

Route::get('novoProdutos', [App\Http\Controllers\AlunoController::class, 'criar']);

Route::post('salvarProdutos', [App\Http\Controllers\AlunoController::class, 'store'])
    ->name('produtos.salvar');

Route::post('atualizarProdutos', [App\Http\Controllers\AlunoController::class, 'update'])
    ->name('Produtos.atualizar');
