<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Marcas;
class MarcaController extends Controller
{
    public function listar()
    {
        $marcas = marcas::all();
        return view('listarmarcas')->with('marcas', $marcas);
    }

    public function listarID($id)
    {
        $marcas = Marcas::find($id);
        if ($marcas) {
            return view('visualizarMarcas')->with('marcas', $marcas);
        } else {
            return redirect('/marcas')->withErrors(['erro' => 'Marca não encontrada!']);
        }
    }

    public function store(Request $request)
    {
        $marcas = new Marca;
        $marcas->nome = $request->nome;
        $marcas->save();

        return redirect()->route('marcas.listar');
    }

    public function criar() {
        return view('novoMarcas');
    }

    public function update(Request $request) {
        $marcas = Marcas::find($request->id);
        $marcas->nome = $request->nome;
        $marcas->save();

        return redirect()->route('marcas.listar');
    }
}
