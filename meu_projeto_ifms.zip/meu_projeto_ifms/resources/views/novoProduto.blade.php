<html>
<h2>Adicionar Produto</h2>
<form method="POST" action="{{ route('produtos.salvar') }}">
    @csrf
    <div>
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>
    </div>
    <div>
        <label for="valor_produtos">Valor do produto:</label>
        <input type="number" name="valor_produto" required>
    </div>
    <div>
        <label for="data_validade">Data de validade:</label>
        <input type="date" name="data_validade" required>
    </div>
    <div>
        <label for="marca_associada">Marca associada:</label>
        <input type="text" name="marca_associada" required>
    </div>
    <button type="submit" class="btn btn-primary">Salvar</button>
</form>
</html>
