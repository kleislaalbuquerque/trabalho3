<html>
<body>
<div>
    <h1>Detalhes do Produto</h1>
    <h2>Adicionar Produto</h2>
    <form method="POST" action="{{ route('produtos.atualizar') }}">
        @csrf
        <div>
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="{{$produtos->nome}}" required>
        </div>
        <div>
            <label for="valor_produtos">Valor do produto:</label>
            <input type="number" name="valor_produto" value="{{$produto->valor_produto}}" required>
        </div>
        <div>
            <label for="data_validade">Data de validade:</label>
            <input type="date" name="date" value="{{$produto->data_validade}}" required>
        </div>
        <div>
            <label for="produtos_associada"></label>
            <input type="text" name="produtos_associados" value="{{$produto->produtos_associados}}" required>
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>
</body>
</html>
