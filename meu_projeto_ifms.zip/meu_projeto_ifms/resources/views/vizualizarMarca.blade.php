<html>
<body>
<div>
    <h1>Detalhes da marca</h1>
    <h2>Adicionar marca</h2>
    <form method="POST" action="{{ route('marcas.atualizar') }}">
        @csrf
        <div>
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="{{$aluno->nome}}" required>
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>
</body>
